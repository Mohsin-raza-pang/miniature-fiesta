import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import Categories from "@/pages/categories";
import Notes from "@/pages/notes";
import AuthPage from "@/pages/auth-page";
import WelcomeModal from "@/components/modals/welcome-modal";
import { useWelcomeModal } from "@/hooks/use-welcome-modal";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

function App() {
  const { showWelcomeModal, closeWelcomeModal } = useWelcomeModal();

  return (
    <AuthProvider>
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <main className="container mx-auto pt-20 pb-16 px-4 md:px-8 flex-grow">
          <Switch>
            <Route path="/" component={Categories} />
            <Route path="/categories/:id" component={Notes} />
            <Route path="/auth" component={AuthPage} />
            <Route component={NotFound} />
          </Switch>
        </main>
        
        <Footer />

        {/* Welcome Modal - shown when users first visit the app */}
        <WelcomeModal 
          open={showWelcomeModal} 
          onClose={closeWelcomeModal} 
        />
        
        <Toaster />
      </div>
    </AuthProvider>
  );
}

export default App;
