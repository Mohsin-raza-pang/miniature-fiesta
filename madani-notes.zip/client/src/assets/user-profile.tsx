import React from 'react';

const UserProfile = () => {
  return (
    <div 
      className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-full border-4 border-primary/30 shadow-xl animate-slide-up"
      style={{
        backgroundImage: `url('/mohsin-profile.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      {/* This is a backup in case the background image fails to load */}
      <div 
        className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 opacity-0 hover:opacity-10 transition-opacity duration-300 rounded-full" 
      />
    </div>
  );
};

export default UserProfile;