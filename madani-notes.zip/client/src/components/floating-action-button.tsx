import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FloatingActionButtonProps {
  onClick: () => void;
}

const FloatingActionButton = ({ onClick }: FloatingActionButtonProps) => {
  return (
    <div className="fixed bottom-20 sm:bottom-24 right-6 z-50">
      <Button 
        onClick={onClick}
        className="fab bg-primary hover:bg-primary/90 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg"
        type="button"
      >
        <Plus size={24} />
      </Button>
    </div>
  );
};

export default FloatingActionButton;
