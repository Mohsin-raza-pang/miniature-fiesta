import { Instagram } from "lucide-react";
import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="w-full p-4 mt-auto border-t bg-card/30 backdrop-blur-sm">
      <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center text-sm">
        <div className="flex items-center space-x-4 mb-2 sm:mb-0">
          <p className="text-muted-foreground">
            Created by <span className="font-medium text-primary">Mohsin Raza</span>
          </p>
          <a 
            href="https://www.instagram.com/mohsinraza.25?utm_source=qr&igsh=cWNyN3I2N2MyMWFy" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-pink-500 hover:text-pink-600 transition-colors"
          >
            <Instagram className="h-4 w-4" />
            <span>Instagram</span>
          </a>
        </div>
        <div className="flex space-x-4">
          <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
            Home
          </Link>
          <Link href="/auth" className="text-muted-foreground hover:text-primary transition-colors">
            Sign In
          </Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;