import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useTheme } from "@/hooks/use-theme";
import ThemeModal from "@/components/modals/theme-modal";
import { useMobile } from "@/hooks/use-mobile";
import { useWelcomeModal } from "@/hooks/use-welcome-modal";
import { useAuth } from "@/hooks/use-auth";
import { Search, Menu, NotepadText, User2, LogOut, LogIn, Moon, Sun, MessageSquareHeart } from "lucide-react";

const Navbar = () => {
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [themeModalOpen, setThemeModalOpen] = useState(false);
  const { resetWelcomeModal } = useWelcomeModal();
  const isMobile = useMobile();
  const { user, logoutMutation } = useAuth();
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Long press for theme modal
  const handleThemeButtonMouseDown = () => {
    const timer = setTimeout(() => {
      setThemeModalOpen(true);
    }, 800);
    
    return () => clearTimeout(timer);
  };

  const toggleTheme = () => {
    const themeOrder: ["light", "dark", "pastel", "tech", "system"] = ["light", "dark", "pastel", "tech", "system"];
    const currentIndex = themeOrder.indexOf(theme);
    const nextIndex = (currentIndex + 1) % themeOrder.length;
    setTheme(themeOrder[nextIndex]);
  };

  return (
    <>
      <nav className="glass z-50 px-6 py-3 fixed top-0 w-full shadow-md">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <Link href="/" className="text-primary font-bold text-xl flex items-center">
              <NotepadText className="mr-2" />
              <span>Madani Notes</span>
            </Link>
            
            <div className="hidden md:flex space-x-4">
              <Link href="/" className={`font-medium ${location === '/' ? 'text-primary' : 'text-foreground/80 hover:text-primary'}`}>
                Notepad
              </Link>
              <Link href="/profile" className={`font-medium ${location === '/profile' ? 'text-primary' : 'text-foreground/80 hover:text-primary'}`}>
                Profile
              </Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative hidden md:block">
              <Input
                type="text"
                placeholder="Search..."
                className="pl-10 pr-4 py-2 rounded-full w-64"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full"
              onClick={toggleTheme}
              onMouseDown={handleThemeButtonMouseDown}
              title="Change theme (long press for more options)"
            >
              {theme === "dark" ? (
                <Moon className="h-5 w-5 text-blue-300" />
              ) : theme === "light" ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : theme === "pastel" ? (
                <svg className="h-5 w-5 text-pink-400" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                </svg>
              ) : theme === "tech" ? (
                <svg className="h-5 w-5 text-blue-500" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                  <line x1="8" y1="21" x2="16" y2="21"></line>
                  <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
              ) : (
                <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="9"></circle>
                  <path d="M12 3a2 2 0 0 0 2 2 2 2 0 0 1 2 2 2 2 0 0 0 2 2 2 2 0 0 1 2 2 2 2 0 0 0-2 2 2 2 0 0 1-2 2 2 2 0 0 0-2 2 2 2 0 0 1-2 2 2 2 0 0 0-2-2 2 2 0 0 1-2-2 2 2 0 0 0-2-2 2 2 0 0 1-2-2 2 2 0 0 0 2-2 2 2 0 0 1 2-2 2 2 0 0 0 2-2 2 2 0 0 1 2-2z"></path>
                </svg>
              )}
            </Button>
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Avatar>
                    {user.profileImage && <AvatarImage src={user.profileImage} alt={user.displayName || user.username} />}
                    <AvatarFallback>{user.displayName?.[0]?.toUpperCase() || user.username[0]?.toUpperCase()}</AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="glass animate-fade-in">
                  <DropdownMenuLabel>
                    {user.displayName || user.username}
                    {user.email && <div className="text-xs text-muted-foreground mt-1">{user.email}</div>}
                  </DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => setThemeModalOpen(true)}>
                    <div className="flex items-center">
                      <svg className="h-4 w-4 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="5" />
                        <path d="M12 1v2" />
                        <path d="M12 21v2" />
                        <path d="M4.22 4.22l1.42 1.42" />
                        <path d="M18.36 18.36l1.42 1.42" />
                        <path d="M1 12h2" />
                        <path d="M21 12h2" />
                        <path d="M4.22 19.78l1.42-1.42" />
                        <path d="M18.36 5.64l1.42-1.42" />
                      </svg>
                      Theme Settings
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={resetWelcomeModal}>
                    <div className="flex items-center">
                      <MessageSquareHeart className="h-4 w-4 mr-2 text-pink-500" />
                      About & Credits
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-destructive" 
                    onClick={() => logoutMutation.mutate()}
                    disabled={logoutMutation.isPending}
                  >
                    {logoutMutation.isPending ? (
                      <div className="flex items-center">
                        <svg className="h-4 w-4 mr-2 animate-spin" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                        </svg>
                        Logging out...
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </div>
                    )}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button variant="outline" size="sm" className="flex items-center">
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign In (Optional)
                </Button>
              </Link>
            )}
            
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={toggleMobileMenu}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-3 pt-2 space-y-3 animate-fade-in">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search..."
                className="pl-10 pr-4 py-2 rounded-full w-full"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
            <Link href="/" className={`block py-2 font-medium ${location === '/' ? 'text-primary' : 'text-foreground/80'}`}>
              Notepad
            </Link>
            {user ? (
              <>
                <div className="flex items-center py-2 font-medium text-foreground/80">
                  <User2 className="h-4 w-4 mr-2" />
                  {user.displayName || user.username}
                </div>
                <button 
                  className="flex items-center py-2 font-medium text-destructive w-full text-left"
                  onClick={() => logoutMutation.mutate()}
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? (
                    <>
                      <svg className="h-4 w-4 mr-2 animate-spin" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                      </svg>
                      Logging out...
                    </>
                  ) : (
                    <>
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </>
                  )}
                </button>
              </>
            ) : (
              <Link href="/auth" className="flex items-center py-2 font-medium text-foreground/80">
                <LogIn className="h-4 w-4 mr-2" />
                Sign In (Optional)
              </Link>
            )}
          </div>
        )}
      </nav>

      <ThemeModal open={themeModalOpen} onClose={() => setThemeModalOpen(false)} />
    </>
  );
};

export default Navbar;
