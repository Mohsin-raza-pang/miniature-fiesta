import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter, 
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { categoryIcons, categoryColors, categoryGradients } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import ImageUpload from "@/components/ui/image-upload";

import { Category as BaseCategory } from "@shared/schema";

// Extended category type that includes the notesCount property
interface Category extends BaseCategory {
  notesCount?: number;
}

interface CreateCategoryModalProps {
  open: boolean;
  onClose: () => void;
  category?: Category | null;
}

const CreateCategoryModal = ({ open, onClose, category }: CreateCategoryModalProps) => {
  const [name, setName] = useState("");
  const [activeTab, setActiveTab] = useState<string>("icon");
  
  // Icon tab
  const [icon, setIcon] = useState(categoryIcons[0].value);
  const [color, setColor] = useState(categoryColors[0].value);
  
  // Gradient tab
  const [gradient, setGradient] = useState<string>(categoryGradients[0].value);
  
  // Image tab
  const [customImage, setCustomImage] = useState<string | null>(null);
  
  // Whether we're in edit mode
  const isEditMode = !!category;
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Set form values when editing a category
  useEffect(() => {
    if (category) {
      setName(category.name);
      setIcon(category.icon || categoryIcons[0].value);
      setColor(category.color || categoryColors[0].value);
      setGradient(category.gradient || categoryGradients[0].value);
      setCustomImage(category.customImage);
      setActiveTab(category.imageType || "icon");
    } else {
      resetForm();
    }
  }, [category]);

  // Create category mutation
  const createCategoryMutation = useMutation({
    mutationFn: async (data: { 
      name: string; 
      icon?: string; 
      color?: string;
      gradient?: string;
      customImage?: string;
      imageType: string;
    }) => {
      const response = await apiRequest("POST", "/api/categories", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category created",
        description: "Your new category has been created successfully.",
      });
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error creating category",
        description: error.message || "There was an error creating the category.",
        variant: "destructive",
      });
    },
  });
  
  // Update category mutation
  const updateCategoryMutation = useMutation({
    mutationFn: async (data: { 
      id: number;
      updates: {
        name: string; 
        icon?: string; 
        color?: string;
        gradient?: string;
        customImage?: string;
        imageType: string;
      }
    }) => {
      const response = await apiRequest("PATCH", `/api/categories/${data.id}`, data.updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category updated",
        description: "The category has been updated successfully.",
      });
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error updating category",
        description: error.message || "There was an error updating the category.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Category name required",
        description: "Please enter a name for your category.",
        variant: "destructive",
      });
      return;
    }
    
    // Create the data object based on the active tab
    const formData: any = {
      name,
      imageType: activeTab
    };
    
    if (activeTab === "icon") {
      formData.icon = icon;
      formData.color = color;
    } else if (activeTab === "gradient") {
      formData.gradient = gradient;
    } else if (activeTab === "custom") {
      formData.customImage = customImage;
    }
    
    // If we're in edit mode, update existing category
    if (isEditMode && category) {
      updateCategoryMutation.mutate({
        id: category.id,
        updates: formData
      });
    } else {
      // Otherwise create new category
      createCategoryMutation.mutate(formData);
    }
  };

  const resetForm = () => {
    setName("");
    setIcon(categoryIcons[0].value);
    setColor(categoryColors[0].value);
    setGradient(categoryGradients[0].value);
    setCustomImage(null);
    setActiveTab("icon");
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditMode ? 'Edit Category' : 'Create New Category'}</DialogTitle>
          <DialogDescription>
            {isEditMode 
              ? 'Edit your category details and appearance below.'
              : 'Create a category to organize your notes. Choose a display style below.'
            }
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Category Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter category name"
              required
            />
          </div>
          
          <Tabs 
            defaultValue="icon" 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="icon">Icon</TabsTrigger>
              <TabsTrigger value="gradient">Gradient</TabsTrigger>
              <TabsTrigger value="custom">Custom Image</TabsTrigger>
            </TabsList>
            
            {/* Icon Tab */}
            <TabsContent value="icon" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Icon</Label>
                <div className="grid grid-cols-5 gap-3 mt-2">
                  {categoryIcons.map((categoryIcon) => (
                    <Button
                      key={categoryIcon.value}
                      type="button"
                      variant="outline"
                      size="icon"
                      className={`p-3 ${icon === categoryIcon.value ? 'bg-muted' : ''}`}
                      onClick={() => setIcon(categoryIcon.value)}
                    >
                      <span className="material-icons">{categoryIcon.value}</span>
                    </Button>
                  ))}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>Color</Label>
                <div className="grid grid-cols-7 gap-3 mt-2">
                  {categoryColors.map((categoryColor) => (
                    <button
                      key={categoryColor.value}
                      type="button"
                      title={categoryColor.label}
                      className={`w-8 h-8 rounded-full bg-${categoryColor.value}-500 border-2 ${
                        color === categoryColor.value 
                          ? 'border-ring shadow-md' 
                          : 'border-background dark:border-background shadow-sm'
                      }`}
                      onClick={() => setColor(categoryColor.value)}
                    />
                  ))}
                </div>
              </div>
              
              <div className="mt-4 bg-muted/50 p-4 rounded-lg">
                <Label>Preview</Label>
                <div className="flex items-center mt-2 p-3 bg-background rounded-lg shadow-sm">
                  <div className={`w-10 h-10 rounded-full bg-${color}-500 flex items-center justify-center mr-3`}>
                    <span className="material-icons text-white">{icon}</span>
                  </div>
                  <span className="font-medium">{name || 'Category name'}</span>
                </div>
              </div>
            </TabsContent>
            
            {/* Gradient Tab */}
            <TabsContent value="gradient" className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Gradient Style</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {categoryGradients.map((gradientOption) => (
                    <button
                      key={gradientOption.value}
                      type="button"
                      className={`h-16 rounded-lg ${gradientOption.value} border-2 p-4 flex items-center justify-center transition-all ${
                        gradient === gradientOption.value 
                          ? 'border-ring shadow-md scale-[1.02]' 
                          : 'border-background/10 shadow-sm'
                      }`}
                      onClick={() => setGradient(gradientOption.value)}
                    >
                      <span className="font-medium text-white drop-shadow-sm">{gradientOption.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mt-4 bg-muted/50 p-4 rounded-lg">
                <Label>Preview</Label>
                <div className="mt-2 p-3 bg-background rounded-lg shadow-sm">
                  <div className={`w-full h-24 ${gradient} rounded-lg flex items-center justify-center mb-2`}>
                    <span className="font-bold text-xl text-white drop-shadow-md">{name || 'Category name'}</span>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            {/* Custom Image Tab */}
            <TabsContent value="custom" className="space-y-4 pt-4">
              <div className="flex flex-col items-center justify-center p-4">
                <Label className="mb-4">Upload Custom Image</Label>
                <ImageUpload 
                  onImageChange={(base64) => setCustomImage(base64)}
                  initialImage={customImage}
                  className="mb-6"
                />
              </div>
              
              <div className="mt-4 bg-muted/50 p-4 rounded-lg">
                <Label>Preview</Label>
                <div className="mt-2 p-3 bg-background rounded-lg shadow-sm">
                  <div className="relative w-full h-32 rounded-lg bg-muted/40 flex items-center justify-center overflow-hidden mb-2">
                    {customImage ? (
                      <img 
                        src={customImage} 
                        alt={name || 'Category'} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-muted-foreground">No image selected</span>
                    )}
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <span className="font-bold text-xl text-white drop-shadow-md">{name || 'Category name'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter className="sm:justify-end pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              disabled={createCategoryMutation.isPending || updateCategoryMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={
                (createCategoryMutation.isPending || updateCategoryMutation.isPending) || 
                !name.trim() || 
                (activeTab === 'custom' && !customImage)
              }
            >
              {createCategoryMutation.isPending || updateCategoryMutation.isPending 
                ? (isEditMode ? "Updating..." : "Creating...") 
                : (isEditMode ? "Update Category" : "Create Category")
              }
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateCategoryModal;
