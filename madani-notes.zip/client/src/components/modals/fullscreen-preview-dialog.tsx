import { useState } from "react";
import { 
  Dialog, 
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, X } from "lucide-react";

interface FullscreenPreviewDialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  content: string;
}

const FullscreenPreviewDialog = ({ 
  open, 
  onClose, 
  title, 
  content 
}: FullscreenPreviewDialogProps) => {
  const [zoomLevel, setZoomLevel] = useState(100);

  const increaseZoom = () => {
    if (zoomLevel < 200) {
      setZoomLevel(prev => prev + 10);
    }
  };

  const decreaseZoom = () => {
    if (zoomLevel > 50) {
      setZoomLevel(prev => prev - 10);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[90vw] md:max-w-[80vw] h-[90vh] w-full flex flex-col">
        <DialogHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 flex-shrink-0">
          <DialogTitle className="text-lg sm:text-xl font-bold truncate mr-2">{title}</DialogTitle>
          <div className="flex items-center space-x-2 self-end sm:self-auto">
            <Button 
              variant="outline" 
              size="icon"
              onClick={decreaseZoom}
              disabled={zoomLevel <= 50}
              className="h-8 w-8 sm:h-9 sm:w-9 bg-background dark:bg-background border-border"
            >
              <ZoomOut className="h-4 w-4 text-foreground" />
            </Button>
            <span className="text-xs sm:text-sm whitespace-nowrap text-foreground">{zoomLevel}%</span>
            <Button 
              variant="outline" 
              size="icon"
              onClick={increaseZoom}
              disabled={zoomLevel >= 200}
              className="h-8 w-8 sm:h-9 sm:w-9 bg-background dark:bg-background border-border"
            >
              <ZoomIn className="h-4 w-4 text-foreground" />
            </Button>
            <Button 
              variant="outline" 
              size="icon"
              onClick={onClose}
              className="h-8 w-8 sm:h-9 sm:w-9 bg-background dark:bg-background border-border"
            >
              <X className="h-5 w-5 text-foreground" />
            </Button>
          </div>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 bg-card rounded-lg shadow-md border border-border/50 my-4" style={{ zoom: `${zoomLevel}%` }}>
          <div 
            className="prose dark:prose-invert max-w-none break-words text-foreground whitespace-pre-wrap min-h-full note-content"
            dangerouslySetInnerHTML={{ __html: content }}
          />
        </div>
        
        <DialogFooter className="mt-2 sm:mt-4">
          <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FullscreenPreviewDialog;