import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Eye } from "lucide-react";
import RichTextEditor from "@/components/ui/rich-text-editor";
import FullscreenPreviewDialog from "./fullscreen-preview-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface NoteEditorModalProps {
  open: boolean;
  onClose: () => void;
  note?: {
    id: number;
    title: string;
    content: string;
  } | null;
  categoryId: number | null;
}

const NoteEditorModal = ({ open, onClose, note, categoryId }: NoteEditorModalProps) => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditMode = !!note;

  useEffect(() => {
    // When the modal opens, set the title and content
    if (open) {
      if (note) {
        setTitle(note.title || "");
        setContent(note.content || "");
      } else {
        // Reset form when creating a new note
        setTitle("");
        setContent("");
      }
    }
  }, [note, open]);

  const createNoteMutation = useMutation({
    mutationFn: async (data: { title: string; content: string; categoryId: number }) => {
      const response = await apiRequest("POST", "/api/notes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories", categoryId, "notes"] });
      toast({
        title: "Note created",
        description: "Your note has been created successfully.",
      });
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error creating note",
        description: error.message || "There was an error creating the note.",
        variant: "destructive",
      });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: async (data: { id: number; title: string; content: string }) => {
      const response = await apiRequest("PATCH", `/api/notes/${data.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories", categoryId, "notes"] });
      toast({
        title: "Note updated",
        description: "Your note has been updated successfully.",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error updating note",
        description: error.message || "There was an error updating the note.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please enter a title for your note.",
        variant: "destructive",
      });
      return;
    }
    
    if (!content.trim()) {
      toast({
        title: "Content required",
        description: "Please enter some content for your note.",
        variant: "destructive",
      });
      return;
    }

    if (isEditMode && note) {
      updateNoteMutation.mutate({ id: note.id, title, content });
    } else if (categoryId) {
      createNoteMutation.mutate({ title, content, categoryId });
    } else {
      toast({
        title: "Error",
        description: "Missing category ID.",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setTitle("");
    setContent("");
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[95vw] sm:max-w-4xl max-h-[90vh] overflow-y-auto p-4 sm:p-6">
        <DialogHeader className="mb-2 sm:mb-4">
          <DialogTitle className="text-xl sm:text-2xl">{isEditMode ? "Edit Note" : "Create New Note"}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="mb-4">
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Note title"
              className="w-full text-xl font-medium px-3 py-2 border-0 border-b-2 border-input focus:outline-none focus:border-primary"
              required
            />
          </div>
          
          <RichTextEditor
            value={content}
            onChange={setContent}
            maxHeight="24rem"
            className="w-full"
          />
          
          <DialogFooter className="flex-col sm:flex-row gap-3 sm:gap-2 pt-4">
            <div className="flex items-center space-x-2 w-full sm:w-auto sm:mr-auto justify-between sm:justify-start">
              <div className="text-xs sm:text-sm text-muted-foreground">
                {content ? content.length : 0} characters
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="flex items-center gap-1"
                onClick={() => setShowPreview(true)}
                disabled={!content.trim()}
              >
                <Eye className="h-4 w-4" />
                <span>View</span>
              </Button>
            </div>
            <div className="flex w-full sm:w-auto gap-2">
              <Button 
                type="button" 
                variant="outline"
                className="flex-1 sm:flex-auto"
                onClick={onClose}
                disabled={createNoteMutation.isPending || updateNoteMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 sm:flex-auto"
                disabled={
                  createNoteMutation.isPending || 
                  updateNoteMutation.isPending || 
                  !title?.trim() || 
                  !(content && content.trim())
                }
              >
                {createNoteMutation.isPending || updateNoteMutation.isPending
                  ? "Saving..."
                  : isEditMode
                  ? "Save Note"
                  : "Create Note"}
              </Button>
            </div>
          </DialogFooter>
          
          {/* Fullscreen Preview Dialog */}
          <FullscreenPreviewDialog
            open={showPreview}
            onClose={() => setShowPreview(false)}
            title={title || "Preview"}
            content={content}
          />
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NoteEditorModal;
