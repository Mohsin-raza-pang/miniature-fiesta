import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Check, Moon, Sun, Monitor, Palette } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { themeOptions } from "@/lib/constants";

interface ThemeModalProps {
  open: boolean;
  onClose: () => void;
}

const ThemeModal = ({ open, onClose }: ThemeModalProps) => {
  const { theme, setTheme } = useTheme();

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto p-4 sm:p-6">
        <DialogHeader className="mb-4">
          <DialogTitle className="text-xl sm:text-2xl flex items-center gap-2">
            <Palette className="h-5 w-5" /> 
            <span>Choose Theme</span>
          </DialogTitle>
          <p className="text-sm text-muted-foreground mt-2">
            Select a theme that matches your style. Changes are applied immediately.
          </p>
        </DialogHeader>

        <RadioGroup value={theme} onValueChange={setTheme} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className={`rounded-lg border-2 p-4 flex flex-col items-center gap-3 cursor-pointer hover:bg-accent/10 transition-colors ${theme === 'light' ? 'border-primary' : 'border-input'}`}>
            <div className="flex justify-between items-center w-full">
              <Label htmlFor="theme-light" className="flex items-center gap-2 cursor-pointer">
                <Sun className="h-4 w-4" />
                <span>Light</span>
              </Label>
              {theme === 'light' && (
                <Check className="h-4 w-4 text-primary" />
              )}
            </div>
            <div className="w-full h-24 rounded-md overflow-hidden border">
              <div className="bg-white h-full w-full flex flex-col">
                <div className="h-4 w-full bg-slate-100"></div>
                <div className="flex flex-1">
                  <div className="w-1/4 bg-slate-50"></div>
                  <div className="flex-1 p-2">
                    <div className="h-3 w-3/4 bg-slate-200 rounded"></div>
                    <div className="h-2 w-1/2 bg-slate-200 rounded mt-2"></div>
                  </div>
                </div>
              </div>
            </div>
            <RadioGroupItem value="light" id="theme-light" className="sr-only" />
          </div>

          <div className={`rounded-lg border-2 p-4 flex flex-col items-center gap-3 cursor-pointer hover:bg-accent/10 transition-colors ${theme === 'dark' ? 'border-primary' : 'border-input'}`}>
            <div className="flex justify-between items-center w-full">
              <Label htmlFor="theme-dark" className="flex items-center gap-2 cursor-pointer">
                <Moon className="h-4 w-4" />
                <span>Dark</span>
              </Label>
              {theme === 'dark' && (
                <Check className="h-4 w-4 text-primary" />
              )}
            </div>
            <div className="w-full h-24 rounded-md overflow-hidden border">
              <div className="bg-gray-950 h-full w-full flex flex-col">
                <div className="h-4 w-full bg-gray-900"></div>
                <div className="flex flex-1">
                  <div className="w-1/4 bg-gray-900"></div>
                  <div className="flex-1 p-2">
                    <div className="h-3 w-3/4 bg-gray-800 rounded"></div>
                    <div className="h-2 w-1/2 bg-gray-800 rounded mt-2"></div>
                  </div>
                </div>
              </div>
            </div>
            <RadioGroupItem value="dark" id="theme-dark" className="sr-only" />
          </div>

          <div className={`rounded-lg border-2 p-4 flex flex-col items-center gap-3 cursor-pointer hover:bg-accent/10 transition-colors ${theme === 'system' ? 'border-primary' : 'border-input'}`}>
            <div className="flex justify-between items-center w-full">
              <Label htmlFor="theme-system" className="flex items-center gap-2 cursor-pointer">
                <Monitor className="h-4 w-4" />
                <span>System</span>
              </Label>
              {theme === 'system' && (
                <Check className="h-4 w-4 text-primary" />
              )}
            </div>
            <div className="w-full h-24 rounded-md overflow-hidden border">
              <div className="h-full w-full flex">
                <div className="w-1/2 bg-white flex flex-col">
                  <div className="h-4 w-full bg-slate-100"></div>
                  <div className="flex-1 p-1">
                    <div className="h-2 w-3/4 bg-slate-200 rounded"></div>
                  </div>
                </div>
                <div className="w-1/2 bg-gray-950 flex flex-col">
                  <div className="h-4 w-full bg-gray-900"></div>
                  <div className="flex-1 p-1">
                    <div className="h-2 w-3/4 bg-gray-800 rounded"></div>
                  </div>
                </div>
              </div>
            </div>
            <RadioGroupItem value="system" id="theme-system" className="sr-only" />
          </div>
          
          <div className={`rounded-lg border-2 p-4 flex flex-col items-center gap-3 cursor-pointer hover:bg-accent/10 transition-colors ${theme === 'pastel' ? 'border-primary' : 'border-input'}`}>
            <div className="flex justify-between items-center w-full">
              <Label htmlFor="theme-pastel" className="flex items-center gap-2 cursor-pointer">
                <span className="text-pink-400">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"></path>
                  </svg>
                </span>
                <span>Pastel</span>
              </Label>
              {theme === 'pastel' && (
                <Check className="h-4 w-4 text-primary" />
              )}
            </div>
            <div className="w-full h-24 rounded-md overflow-hidden border">
              <div className="bg-pink-50 h-full w-full flex flex-col">
                <div className="h-4 w-full bg-purple-100"></div>
                <div className="flex flex-1">
                  <div className="w-1/4 bg-blue-50"></div>
                  <div className="flex-1 p-2">
                    <div className="h-3 w-3/4 bg-yellow-100 rounded"></div>
                    <div className="h-2 w-1/2 bg-green-100 rounded mt-2"></div>
                  </div>
                </div>
              </div>
            </div>
            <RadioGroupItem value="pastel" id="theme-pastel" className="sr-only" />
          </div>
          
          <div className={`rounded-lg border-2 p-4 flex flex-col items-center gap-3 cursor-pointer hover:bg-accent/10 transition-colors ${theme === 'tech' ? 'border-primary' : 'border-input'}`}>
            <div className="flex justify-between items-center w-full">
              <Label htmlFor="theme-tech" className="flex items-center gap-2 cursor-pointer">
                <span className="text-blue-500">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                    <line x1="8" y1="21" x2="16" y2="21"></line>
                    <line x1="12" y1="17" x2="12" y2="21"></line>
                  </svg>
                </span>
                <span>Tech</span>
              </Label>
              {theme === 'tech' && (
                <Check className="h-4 w-4 text-primary" />
              )}
            </div>
            <div className="w-full h-24 rounded-md overflow-hidden border">
              <div className="bg-slate-900 h-full w-full flex flex-col">
                <div className="h-4 w-full bg-blue-900"></div>
                <div className="flex flex-1">
                  <div className="w-1/4 bg-slate-800"></div>
                  <div className="flex-1 p-2">
                    <div className="h-3 w-3/4 bg-blue-800 rounded"></div>
                    <div className="h-2 w-1/2 bg-blue-700 rounded mt-2"></div>
                  </div>
                </div>
              </div>
            </div>
            <RadioGroupItem value="tech" id="theme-tech" className="sr-only" />
          </div>
        </RadioGroup>

        <DialogFooter className="mt-6">
          <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ThemeModal;