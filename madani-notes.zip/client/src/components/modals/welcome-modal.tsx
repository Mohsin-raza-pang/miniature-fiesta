import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Instagram } from "lucide-react";

interface WelcomeModalProps {
  open: boolean;
  onClose: () => void;
}

const WelcomeModal = ({ open, onClose }: WelcomeModalProps) => {
  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto p-6 sm:p-8 animate-fade-in">
        <DialogHeader className="mb-5 text-center space-y-4">
          <div className="flex justify-center mb-2">
            <div className="w-20 h-20 rounded-full flex items-center justify-center bg-primary/20">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="48"
                height="48"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary"
              >
                <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
                <path d="M8 7h6" />
                <path d="M8 11h8" />
                <path d="M8 15h5" />
              </svg>
            </div>
          </div>
          
          <DialogTitle className="text-xl sm:text-2xl font-bold tracking-tight">Welcome to Madani Notes</DialogTitle>
          <DialogDescription className="text-center mt-2 text-base">
            Developed by <span className="font-bold text-primary text-lg">MOHSIN RAZA</span>
          </DialogDescription>
        </DialogHeader>
        
        <div className="text-center mb-8">
          <p className="text-muted-foreground mb-6 text-sm sm:text-base max-w-xs mx-auto">
            Thank you for using Madani Notes! This professional notepad application helps you organize your thoughts and notes.
          </p>
          
          <a 
            href="https://www.instagram.com/mohsinraza.25?utm_source=qr&igsh=cWNyN3I2N2MyMWFy" 
            target="_blank" 
            rel="noopener noreferrer"
            className="instagram-gradient inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm sm:text-base"
          >
            <Instagram className="h-5 w-5" />
            <span>Follow on Instagram</span>
          </a>
        </div>
        
        <div className="flex justify-center">
          <Button 
            onClick={onClose}
            className="w-full sm:w-auto px-6"
            size="lg"
          >
            Continue to App
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WelcomeModal;