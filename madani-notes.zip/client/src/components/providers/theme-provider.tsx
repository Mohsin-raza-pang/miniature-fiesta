import { createContext, useEffect, useState } from "react";

type Theme = "light" | "dark" | "system" | "pastel" | "tech";

type ThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: Theme;
};

type ThemeProviderState = {
  theme: Theme;
  setTheme: (theme: Theme) => void;
};

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
};

export const ThemeProviderContext = createContext<ThemeProviderState>(initialState);

export function ThemeProvider({
  children,
  defaultTheme = "system",
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(
    () => (localStorage.getItem("theme") as Theme) || defaultTheme
  );

  useEffect(() => {
    const root = window.document.documentElement;
    
    // First, remove all theme classes
    root.classList.remove("light", "dark", "theme-pastel", "theme-tech");

    if (theme === "system") {
      // For system theme, detect user's preference
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
      root.classList.add(systemTheme);
    } else if (theme === "light" || theme === "dark") {
      // For basic themes, just add the theme class
      root.classList.add(theme);
    } else if (theme === "pastel" || theme === "tech") {
      // These are now direct themes rather than theme modifiers
      root.classList.add(theme);
    }

    // Save the theme preference
    localStorage.setItem("theme", theme);
  }, [theme]);

  const value = {
    theme,
    setTheme: (newTheme: Theme) => setTheme(newTheme),
  };

  return (
    <ThemeProviderContext.Provider value={value}>
      {children}
    </ThemeProviderContext.Provider>
  );
}
