import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Image, Upload, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImageUploadProps {
  onImageChange: (base64: string | null) => void;
  className?: string;
  initialImage?: string | null;
}

const MAX_FILE_SIZE = 1024 * 1024; // 1MB
const ALLOWED_FILE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];

const ImageUpload: React.FC<ImageUploadProps> = ({ onImageChange, className, initialImage }) => {
  const [preview, setPreview] = useState<string | null>(initialImage || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  // Update preview if initialImage changes (when editing)
  useEffect(() => {
    if (initialImage) {
      setPreview(initialImage);
      onImageChange(initialImage);
    }
  }, [initialImage, onImageChange]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a JPG, PNG, GIF, or SVG image.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size
    if (file.size > MAX_FILE_SIZE) {
      toast({
        title: "File too large",
        description: "Image should be less than 1MB in size.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setPreview(base64);
      onImageChange(base64);
    };
    reader.readAsDataURL(file);
  };

  const clearImage = () => {
    setPreview(null);
    onImageChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept={ALLOWED_FILE_TYPES.join(',')}
        className="hidden"
      />

      {preview ? (
        <div className="relative">
          <img 
            src={preview} 
            alt="Preview" 
            className="w-24 h-24 rounded-full object-cover border-2 border-primary/30"
          />
          <button 
            onClick={clearImage}
            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground p-1 rounded-full"
            type="button"
          >
            <X size={14} />
          </button>
        </div>
      ) : (
        <Button 
          type="button" 
          variant="outline" 
          onClick={triggerFileInput}
          className="w-24 h-24 rounded-full flex flex-col items-center justify-center gap-1 border-dashed"
        >
          <Image size={20} />
          <span className="text-xs">Upload</span>
        </Button>
      )}
      <p className="text-xs text-muted-foreground mt-2">
        JPG, PNG, GIF or SVG (max. 1MB)
      </p>
    </div>
  );
};

export default ImageUpload;