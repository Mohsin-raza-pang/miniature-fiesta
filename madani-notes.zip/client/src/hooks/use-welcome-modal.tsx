import { useState, useEffect } from "react";

export function useWelcomeModal() {
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);

  useEffect(() => {
    // Don't show welcome modal automatically
    setShowWelcomeModal(false);
  }, []);

  const closeWelcomeModal = () => {
    setShowWelcomeModal(false);
    // We're keeping this for potential future use, but not checking it
    localStorage.setItem("hasSeenWelcome", "true");
  };

  // Function to reopen the welcome modal from menu
  const resetWelcomeModal = () => {
    setShowWelcomeModal(true);
  };

  return {
    showWelcomeModal,
    closeWelcomeModal,
    resetWelcomeModal
  };
}