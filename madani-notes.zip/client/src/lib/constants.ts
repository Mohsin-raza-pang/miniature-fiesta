// Category Icons
export const categoryIcons = [
  { label: "Notes", value: "note_alt" },
  { label: "Work", value: "work" },
  { label: "Code", value: "code" },
  { label: "Ideas", value: "lightbulb" },
  { label: "Learning", value: "school" },
  { label: "Meetings", value: "groups" },
  { label: "Tasks", value: "task" },
  { label: "Books", value: "local_library" },
  { label: "Events", value: "event_note" },
  { label: "Thoughts", value: "psychology" },
];

// Category Colors
export const categoryColors = [
  { label: "Primary", value: "primary" },
  { label: "Secondary", value: "secondary" },
  { label: "Accent", value: "accent" },
  { label: "Green", value: "green" },
  { label: "Blue", value: "blue" },
  { label: "Yellow", value: "yellow" },
  { label: "Red", value: "red" },
  { label: "Gray", value: "gray" },
  { label: "Purple", value: "purple" },
  { label: "Pink", value: "pink" },
  { label: "Indigo", value: "indigo" },
  { label: "Teal", value: "teal" },
  { label: "Orange", value: "orange" },
];

// Category Gradients
export const categoryGradients = [
  { 
    label: "Sunset", 
    value: "bg-gradient-to-r from-orange-500 to-pink-500" 
  },
  { 
    label: "Ocean", 
    value: "bg-gradient-to-r from-blue-500 to-teal-400" 
  },
  { 
    label: "Forest", 
    value: "bg-gradient-to-r from-green-400 to-emerald-600" 
  },
  { 
    label: "Berry", 
    value: "bg-gradient-to-r from-purple-600 to-pink-500" 
  },
  { 
    label: "Fire", 
    value: "bg-gradient-to-r from-red-500 to-orange-500" 
  },
  { 
    label: "Midnight", 
    value: "bg-gradient-to-r from-indigo-600 to-purple-600" 
  },
  { 
    label: "Instagram", 
    value: "bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500" 
  },
  { 
    label: "Magic", 
    value: "bg-gradient-to-r from-blue-600 via-purple-500 to-pink-400" 
  },
];

// Theme Options
export const themeOptions = [
  { label: "Light", value: "light" },
  { label: "Dark", value: "dark" },
];
