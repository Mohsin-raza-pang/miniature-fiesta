import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, formatDistanceToNow, isToday, isYesterday } from "date-fns"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Removes HTML tags from a string and returns only the text content
 * Useful for displaying note content in preview mode without HTML formatting
 */
export function stripHtml(html: string): string {
  if (!html) return "";
  
  // Create a temporary DOM element to parse the HTML
  const tempElement = document.createElement("div");
  tempElement.innerHTML = html;
  
  // Return the text content of the element (without HTML tags)
  return tempElement.textContent || tempElement.innerText || "";
}

/**
 * Formats a date into a human-readable string
 * If the date is today, returns "Today at [time]"
 * If the date is yesterday, returns "Yesterday at [time]"
 * If the date is within the last 7 days, returns "[day] at [time]"
 * Otherwise, returns the full date in the format "MMM d, yyyy"
 */
export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return "";
  
  try {
    const dateObj = typeof date === "string" ? new Date(date) : date;
    
    if (!(dateObj instanceof Date) || isNaN(dateObj.getTime())) {
      return "";
    }
    
    if (isToday(dateObj)) {
      return `Today at ${format(dateObj, "h:mm a")}`;
    } else if (isYesterday(dateObj)) {
      return `Yesterday at ${format(dateObj, "h:mm a")}`;
    } else if (dateObj > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)) {
      // Within the last 7 days
      return `${formatDistanceToNow(dateObj, { addSuffix: true })}`;
    } else {
      return format(dateObj, "MMM d, yyyy");
    }
  } catch (error) {
    console.error("Error formatting date:", error);
    return "";
  }
}
