import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Pencil, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import FloatingActionButton from "@/components/floating-action-button";
import CreateCategoryModal from "@/components/modals/create-category-modal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Category as BaseCategory } from "@shared/schema";

// Extended category type that includes the notesCount property 
// which is added by the backend but not in the schema
interface Category extends BaseCategory {
  notesCount?: number;
}

const Categories = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [categoryToEdit, setCategoryToEdit] = useState<Category | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Load categories
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Delete category mutation
  const deleteCategoryMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/categories/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories"] });
      toast({
        title: "Category deleted",
        description: "The category has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error deleting category",
        description: error.message || "There was an error deleting the category.",
        variant: "destructive",
      });
    },
  });

  // Handle delete category
  const handleDeleteCategory = (id: number) => {
    deleteCategoryMutation.mutate(id);
  };

  // Handle edit category
  const handleEditCategory = (category: Category) => {
    setCategoryToEdit(category);
    setShowCreateModal(true);
  };

  // Filter and sort categories
  const filteredCategories = categories
    ? categories
        .filter((category) =>
          category.name.toLowerCase().includes(searchTerm.toLowerCase())
        )
        .sort((a, b) => {
          if (sortBy === "name") {
            return a.name.localeCompare(b.name);
          } else if (sortBy === "recent") {
            return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
          }
          return 0;
        })
    : [];

  // Category color mapping
  const getCategoryColorClass = (color: string) => {
    const colorMap: { [key: string]: string } = {
      primary: "from-primary-500 to-primary-700",
      secondary: "from-secondary-500 to-secondary-600",
      accent: "from-accent-500 to-accent-600",
      green: "from-green-500 to-emerald-600",
      blue: "from-blue-500 to-blue-600",
      yellow: "from-yellow-500 to-amber-600",
      red: "from-red-500 to-red-600",
      gray: "from-gray-500 to-gray-600",
      purple: "from-purple-500 to-purple-700",
      pink: "from-pink-500 to-pink-700",
      indigo: "from-indigo-500 to-indigo-700",
      teal: "from-teal-500 to-teal-700",
      orange: "from-orange-500 to-orange-700",
    };
    
    return colorMap[color] || colorMap.primary;
  };
  
  // Render the category header based on imageType
  const renderCategoryHeader = (category: Category) => {
    // If the category has a custom image
    if (category.imageType === 'custom' && category.customImage) {
      return (
        <div className="relative h-24 w-full overflow-hidden">
          <img 
            src={category.customImage} 
            alt={category.name} 
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
            <h3 className="text-white text-xl font-bold">{category.name}</h3>
          </div>
        </div>
      );
    }
    
    // If the category uses a gradient
    if (category.imageType === 'gradient' && category.gradient) {
      return (
        <div className={`h-24 ${category.gradient} p-4 flex items-center justify-center`}>
          <h3 className="text-white text-xl font-bold drop-shadow-sm">{category.name}</h3>
        </div>
      );
    }
    
    // Default to icon + color style
    return (
      <div className={`h-24 bg-gradient-to-r ${getCategoryColorClass(category.color || 'primary')} p-4 flex items-center justify-center`}>
        <span className="material-icons text-white text-4xl">{category.icon || 'note_alt'}</span>
      </div>
    );
  };

  return (
    <>
      <div className="animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <h1 className="text-2xl md:text-3xl font-bold mb-4 md:mb-0">My Categories</h1>
          
          <div className="w-full md:w-auto flex flex-col md:flex-row gap-3">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search categories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="md:w-64 pl-10"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="md:w-36">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="recent">Recently Updated</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-24 w-full" />
                <CardContent className="p-5">
                  <div className="flex justify-between items-start">
                    <Skeleton className="h-6 w-1/2" />
                    <div className="flex space-x-1">
                      <Skeleton className="h-6 w-6 rounded" />
                      <Skeleton className="h-6 w-6 rounded" />
                    </div>
                  </div>
                  <Skeleton className="h-4 w-1/3 mt-2" />
                  <Skeleton className="h-4 w-1/4 mt-4" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredCategories.length === 0 ? (
          <div className="text-center py-16 rounded-xl border border-dashed bg-background/50">
            <h3 className="text-lg font-medium">No categories found</h3>
            <p className="text-muted-foreground mt-1">
              {searchTerm
                ? "Try a different search term"
                : "Create your first category to get started"}
            </p>
            <Button
              onClick={() => setShowCreateModal(true)}
              className="mt-4"
              variant="default"
            >
              Create Category
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredCategories.map((category) => (
              <Card key={category.id} className="card glass rounded-xl overflow-hidden shadow-lg animate-slide-up">
                {renderCategoryHeader(category)}
                <CardContent className="p-5">
                  <div className="flex justify-between items-start">
                    {/* Don't show name again if already in header (gradient or custom image) */}
                    {category.imageType === 'icon' && (
                      <h3 className="text-lg font-semibold">{category.name}</h3>
                    )}
                    {(category.imageType === 'gradient' || category.imageType === 'custom') && (
                      <div className="flex-1"></div> 
                    )}
                    <div className="flex space-x-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={() => handleEditCategory(category)}
                      >
                        <Pencil className="h-4 w-4 text-muted-foreground" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7"
                          >
                            <Trash2 className="h-4 w-4 text-muted-foreground" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Category</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this category? This will also delete all notes within this category. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteCategory(category.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm mt-2">
                    {category.notesCount ?? 0} notes
                  </p>
                  <div className="mt-4">
                    <Link
                      href={`/categories/${category.id}`}
                      className="text-primary text-sm font-medium hover:underline"
                    >
                      View Notes &rarr;
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <FloatingActionButton onClick={() => setShowCreateModal(true)} />
      
      <CreateCategoryModal
        open={showCreateModal}
        onClose={() => {
          setShowCreateModal(false);
          setCategoryToEdit(null);
        }}
        category={categoryToEdit}
      />
    </>
  );
};

export default Categories;
