import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  ChevronLeft,
  Search,
  Pin, 
  PinOff,
  Heart,
  Trash2,
  Eye
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import FloatingActionButton from "@/components/floating-action-button";
import NoteEditorModal from "@/components/modals/note-editor-modal";
import FullscreenPreviewDialog from "@/components/modals/fullscreen-preview-dialog";
import { formatDate, stripHtml } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Note, Category } from "@shared/schema";

const Notes = () => {
  const [match, params] = useRoute("/categories/:id");
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [showNoteEditor, setShowNoteEditor] = useState(false);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [previewNote, setPreviewNote] = useState<Note | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const categoryId = match ? parseInt(params.id) : null;

  // Load category details
  const { data: category, isLoading: isLoadingCategory } = useQuery<Category>({
    queryKey: ["/api/categories", categoryId],
    enabled: !!categoryId,
  });

  // Load notes for this category
  const { data: notes, isLoading: isLoadingNotes } = useQuery<Note[]>({
    queryKey: ["/api/categories", categoryId, "notes"],
    queryFn: async () => {
      if (!categoryId) return [];
      const response = await apiRequest("GET", `/api/categories/${categoryId}/notes`);
      return response.json();
    },
    enabled: !!categoryId,
  });

  // Toggle pin note mutation
  const togglePinMutation = useMutation({
    mutationFn: async ({ id, isPinned }: { id: number; isPinned: boolean }) => {
      const response = await apiRequest("PATCH", `/api/notes/${id}/pin`, { isPinned });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories", categoryId, "notes"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "There was an error updating the note.",
        variant: "destructive",
      });
    },
  });

  // Toggle favorite note mutation
  const toggleFavoriteMutation = useMutation({
    mutationFn: async ({ id, isFavorite }: { id: number; isFavorite: boolean }) => {
      const response = await apiRequest("PATCH", `/api/notes/${id}/favorite`, { isFavorite });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories", categoryId, "notes"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "There was an error updating the note.",
        variant: "destructive",
      });
    },
  });

  // Delete note mutation
  const deleteNoteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/notes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/categories", categoryId, "notes"] });
      toast({
        title: "Note deleted",
        description: "The note has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error deleting note",
        description: error.message || "There was an error deleting the note.",
        variant: "destructive",
      });
    },
  });

  const handlePinToggle = (note: Note, e: React.MouseEvent) => {
    e.stopPropagation();
    togglePinMutation.mutate({ id: note.id, isPinned: !note.isPinned });
  };

  const handleFavoriteToggle = (note: Note, e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavoriteMutation.mutate({ id: note.id, isFavorite: !note.isFavorite });
  };

  const handleDeleteNote = (id: number) => {
    // Immediately close any open dialogs by force
    const dialogs = document.querySelectorAll('[role="dialog"]');
    dialogs.forEach(dialog => {
      if (dialog.parentElement) {
        // Attempt to force close the dialog
        const closeButton = dialog.querySelector('button[data-state="closed"]');
        if (closeButton instanceof HTMLButtonElement) {
          closeButton.click();
        }
      }
    });
    
    // Then trigger the mutation
    deleteNoteMutation.mutate(id);
  };

  const handleNoteClick = (note: Note) => {
    setSelectedNote(note);
    setShowNoteEditor(true);
  };

  const handleCreateNote = () => {
    setSelectedNote(null);
    setShowNoteEditor(true);
  };
  
  const handlePreviewNote = (note: Note, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent opening the editor
    setPreviewNote(note);
    setShowPreview(true);
  };

  // Filter notes based on search term
  const filteredNotes = notes
    ? notes
        .filter(
          (note) => {
            // Make sure title and content exist before calling toLowerCase
            const title = note?.title || '';
            const content = note?.content || '';
            
            return title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  content.toLowerCase().includes(searchTerm.toLowerCase());
          }
        )
        .sort((a, b) => {
          // First sort by pinned status
          if (a.isPinned && !b.isPinned) return -1;
          if (!a.isPinned && b.isPinned) return 1;
          
          // Then by creation date (newest first)
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        })
    : [];

  const isLoading = isLoadingCategory || isLoadingNotes;

  return (
    <>
      <div id="notesPage">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div className="flex items-center mb-4 md:mb-0">
            <Button
              variant="ghost"
              size="icon"
              className="mr-4 rounded-full"
              onClick={() => navigate("/")}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              {isLoading ? (
                <>
                  <Skeleton className="h-8 w-48" />
                  <Skeleton className="h-4 w-20 mt-1" />
                </>
              ) : (
                <>
                  <h1 className="text-2xl md:text-3xl font-bold">{category?.name}</h1>
                  <p className="text-muted-foreground text-sm">{filteredNotes.length} notes</p>
                </>
              )}
            </div>
          </div>
          
          <div className="w-full md:w-auto">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search notes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full md:w-64"
              />
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="card glass rounded-xl overflow-hidden border border-border/40 shadow-lg animate-pulse">
                <CardContent className="p-4 md:p-5 relative">
                  {/* Potential pin indicator position */}
                  {i % 3 === 0 && (
                    <div className="absolute -top-1 -right-1 h-8 w-8 overflow-hidden">
                      <div className="absolute transform rotate-45 bg-muted/70 text-muted-foreground text-[8px] font-bold py-1 right-[-20px] top-[11px] w-[60px] text-center">
                        <Skeleton className="h-2 w-full" />
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-start">
                    <Skeleton className="h-6 w-1/2" />
                    <div className="flex space-x-1">
                      <Skeleton className="h-7 w-7 rounded-full" />
                      <Skeleton className="h-7 w-7 rounded-full" />
                      <Skeleton className="h-7 w-7 rounded-full" />
                    </div>
                  </div>
                  <div className="mt-3 space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <Skeleton className="h-3 w-1/3" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                  
                  {/* Potential favorite indicator */}
                  {i % 4 === 0 && (
                    <div className="absolute top-0 left-0 w-3 h-3 bg-muted rounded-br-sm rounded-tl-md"></div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredNotes.length === 0 ? (
          <div className="text-center py-16 rounded-xl border border-dashed bg-card/30 glass animate-fade-in">
            <div className="flex flex-col items-center justify-center">
              {searchTerm ? (
                <svg 
                  className="h-16 w-16 text-muted-foreground/50 mb-4" 
                  xmlns="http://www.w3.org/2000/svg" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10h4" />
                </svg>
              ) : (
                <svg 
                  className="h-16 w-16 text-muted-foreground/50 mb-4" 
                  xmlns="http://www.w3.org/2000/svg" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
              )}
              
              <h3 className="text-lg font-medium">
                {searchTerm ? "No notes match your search" : "No notes yet"}
              </h3>
              <p className="text-muted-foreground mt-2 max-w-md mx-auto">
                {searchTerm
                  ? "Try a different search term or clear your search to see all notes"
                  : "Create your first note in this category to start organizing your thoughts"}
              </p>
              
              <div className="mt-6 flex items-center justify-center gap-4">
                {searchTerm && (
                  <Button
                    onClick={() => setSearchTerm('')}
                    variant="outline"
                  >
                    Clear Search
                  </Button>
                )}
                <Button
                  onClick={handleCreateNote}
                  variant="default"
                  className="shadow-sm"
                >
                  <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Create Note
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {filteredNotes.map((note) => (
              <Card
                key={note.id}
                className={`card glass rounded-xl overflow-hidden border border-border/40 shadow-lg animate-slide-up cursor-pointer group h-full transition-all duration-200 ${
                  note.isPinned ? 'ring-2 ring-primary/40 ring-offset-2 ring-offset-background' : ''
                }`}
                onClick={() => handleNoteClick(note)}
              >
                <CardContent className="p-4 md:p-5 flex flex-col h-full relative">
                  {/* Pin indicator */}
                  {note.isPinned && (
                    <div className="absolute -top-1 -right-1 h-8 w-8 overflow-hidden">
                      <div className="absolute transform rotate-45 bg-primary text-primary-foreground text-[8px] font-bold py-1 right-[-20px] top-[11px] w-[60px] text-center">
                        PINNED
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-start">
                    <h3 className="text-base md:text-lg font-semibold truncate max-w-[70%]">{note.title}</h3>
                    <div className="flex space-x-1">
                      <Button
                        size="icon"
                        variant="outline"
                        className={`h-7 w-7 bg-background dark:bg-background border-muted ${note.isPinned ? 'text-primary border-primary/50' : 'text-foreground'}`}
                        onClick={(e) => handlePinToggle(note, e)}
                        title={note.isPinned ? "Unpin note" : "Pin note"}
                      >
                        {note.isPinned ? <Pin className="h-4 w-4" /> : <PinOff className="h-4 w-4" />}
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        className={`h-7 w-7 bg-background dark:bg-background border-muted ${note.isFavorite ? 'text-accent border-accent/50' : 'text-foreground'}`}
                        onClick={(e) => handleFavoriteToggle(note, e)}
                        title={note.isFavorite ? "Remove from favorites" : "Add to favorites"}
                      >
                        <Heart className={`h-4 w-4 ${note.isFavorite ? 'fill-current' : ''}`} />
                      </Button>
                      <Button
                        size="icon"
                        variant="outline"
                        className="h-7 w-7 text-foreground bg-background dark:bg-background border-muted"
                        onClick={(e) => handlePreviewNote(note, e)}
                        title="Preview note"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            size="icon"
                            variant="outline"
                            className="h-7 w-7 text-foreground hover:text-destructive bg-background dark:bg-background border-muted"
                            onClick={(e) => e.stopPropagation()}
                            title="Delete note"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Note</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this note? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={(e) => {
                                e.stopPropagation(); // Stop event propagation
                                handleDeleteNote(note.id);
                              }}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                  <div className="mt-2 md:mt-3 flex-grow">
                    <p className="line-clamp-3 text-sm md:text-base text-muted-foreground">{stripHtml(note.content)}</p>
                  </div>
                  <div className="mt-3 md:mt-4 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">{formatDate(note.createdAt)}</span>
                    <div className="bg-primary/10 dark:bg-primary/20 text-primary font-medium hidden sm:inline-block px-2 py-1 rounded-md group-hover:translate-x-1 transition-transform">
                      View &rarr;
                    </div>
                  </div>
                  
                  {/* Favorite indicator */}
                  {note.isFavorite && (
                    <div className="absolute top-0 left-0 w-3 h-3 bg-accent rounded-br-sm rounded-tl-md"></div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <FloatingActionButton onClick={handleCreateNote} />
      
      <NoteEditorModal
        open={showNoteEditor}
        onClose={() => {
          setShowNoteEditor(false);
          setSelectedNote(null);
        }}
        note={selectedNote}
        categoryId={categoryId}
      />
      
      {/* Fullscreen Preview Dialog */}
      <FullscreenPreviewDialog
        open={showPreview}
        onClose={() => setShowPreview(false)}
        title={previewNote?.title || ""}
        content={previewNote?.content || ""}
      />
    </>
  );
};

export default Notes;
