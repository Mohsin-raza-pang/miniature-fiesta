import { db } from "./index";
import * as schema from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  try {
    console.log("Seeding database...");

    // Create initial categories
    const initialCategories = [
      {
        name: "Work Notes",
        icon: "work",
        color: "primary",
      },
      {
        name: "Personal Projects",
        icon: "code",
        color: "secondary",
      },
      {
        name: "Ideas",
        icon: "lightbulb",
        color: "accent",
      },
      {
        name: "Learning",
        icon: "school",
        color: "green",
      },
      {
        name: "Meeting Notes",
        icon: "groups",
        color: "blue",
      },
    ];

    // Insert categories if they don't exist
    for (const categoryData of initialCategories) {
      const existingCategory = await db.query.categories.findFirst({
        where: eq(schema.categories.name, categoryData.name),
      });

      if (!existingCategory) {
        const [newCategory] = await db.insert(schema.categories)
          .values({
            name: categoryData.name,
            icon: categoryData.icon,
            color: categoryData.color,
            createdAt: new Date(),
            updatedAt: new Date(),
          })
          .returning();
        
        console.log(`Created category: ${newCategory.name}`);
      }
    }

    // Get all categories to add notes to them
    const allCategories = await db.query.categories.findMany();

    // Sample notes for Work Notes category
    const workCategory = allCategories.find(c => c.name === "Work Notes");
    if (workCategory) {
      const workNotes = [
        {
          title: "API Documentation Notes",
          content: `<p>RESTful API endpoints for the user authentication service. Includes details on request/response formats, authentication methods, and error codes.</p>
<p><br></p>
<p><strong>Authentication Endpoints:</strong></p>
<ul>
  <li>POST /api/auth/login</li>
  <li>POST /api/auth/register</li>
  <li>POST /api/auth/refresh-token</li>
  <li>GET /api/auth/verify-email/:token</li>
  <li>POST /api/auth/forgot-password</li>
  <li>POST /api/auth/reset-password</li>
</ul>
<p><br></p>
<p><strong>Request Format:</strong></p>
<p>All requests should include Content-Type: application/json header.</p>
<p><br></p>
<p><strong>Response Format:</strong></p>
<p>All responses will return JSON with the following structure:</p>
<p>{</p>
<p>&nbsp; "success": boolean,</p>
<p>&nbsp; "data": object | null,</p>
<p>&nbsp; "error": string | null</p>
<p>}</p>`,
          isPinned: true,
          isFavorite: false,
        },
        {
          title: "Database Migration Plan",
          content: `<p>Steps for migrating from MySQL to PostgreSQL:</p>
<ol>
  <li>Create schema mappings</li>
  <li>Set up data validation procedures</li>
  <li>Plan downtime window</li>
  <li>Test rollback procedures</li>
</ol>`,
          isPinned: false,
          isFavorite: true,
        },
        {
          title: "Deployment Checklist",
          content: `<p>Production deployment checklist:</p>
<ul>
  <li>Run automated tests</li>
  <li>Verify infrastructure configs</li>
  <li>Update documentation</li>
  <li>Send stakeholder notifications</li>
  <li>Monitor metrics after deploy</li>
</ul>`,
          isPinned: false,
          isFavorite: false,
        },
        {
          title: "Weekly Team Goals",
          content: `<p>Focus areas for next sprint:</p>
<ul>
  <li>Finish user authentication module</li>
  <li>Refactor dashboard components</li>
  <li>Improve test coverage to 85%</li>
</ul>`,
          isPinned: false,
          isFavorite: false,
        },
      ];

      for (const noteData of workNotes) {
        const existingNote = await db.query.notes.findFirst({
          where: eq(schema.notes.title, noteData.title),
        });

        if (!existingNote) {
          const [newNote] = await db.insert(schema.notes)
            .values({
              title: noteData.title,
              content: noteData.content,
              categoryId: workCategory.id,
              isPinned: noteData.isPinned,
              isFavorite: noteData.isFavorite,
              createdAt: new Date(),
              updatedAt: new Date(),
            })
            .returning();
          
          console.log(`Created note: ${newNote.title}`);
        }
      }
    }

    // Sample notes for Ideas category
    const ideasCategory = allCategories.find(c => c.name === "Ideas");
    if (ideasCategory) {
      const ideasNotes = [
        {
          title: "Mobile App Concept",
          content: `<p>App idea for productivity tracking:</p>
<ul>
  <li>Time tracking with pomodoro technique</li>
  <li>Project categorization</li>
  <li>Daily/weekly reports</li>
  <li>Integration with calendar</li>
</ul>
<p>Target audience: freelancers and remote workers</p>`,
          isPinned: true,
          isFavorite: true,
        },
        {
          title: "Blog Post Topics",
          content: `<p>Potential technical blog posts:</p>
<ol>
  <li>Understanding React Hooks in depth</li>
  <li>PostgreSQL performance optimization techniques</li>
  <li>Building accessible web applications</li>
  <li>Serverless architecture pros and cons</li>
</ol>`,
          isPinned: false,
          isFavorite: false,
        },
      ];

      for (const noteData of ideasNotes) {
        const existingNote = await db.query.notes.findFirst({
          where: eq(schema.notes.title, noteData.title),
        });

        if (!existingNote) {
          const [newNote] = await db.insert(schema.notes)
            .values({
              title: noteData.title,
              content: noteData.content,
              categoryId: ideasCategory.id,
              isPinned: noteData.isPinned,
              isFavorite: noteData.isFavorite,
              createdAt: new Date(),
              updatedAt: new Date(),
            })
            .returning();
          
          console.log(`Created note: ${newNote.title}`);
        }
      }
    }

    console.log("Database seeding completed!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

seed();
