import express, { type Express, type Request, type Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, requireAuth, getOptionalUser } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";

// Set up multer for image uploads
const uploadDir = path.join(process.cwd(), "public", "uploads");

// Create upload directory if it doesn't exist
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage_config = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, uploadDir);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const extension = path.extname(file.originalname).toLowerCase();
    cb(null, uniqueSuffix + extension);
  },
});

const upload = multer({
  storage: storage_config,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB
  },
  fileFilter: (_req, file, cb) => {
    const filetypes = /jpeg|jpg|png|gif|webp/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error("Only images are allowed"));
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  // Categories endpoints
  app.get("/api/categories", getOptionalUser, async (req: any, res) => {
    try {
      // If user is logged in, get their categories, otherwise get public categories
      const userId = req.isAuthenticated() ? req.user.id : null;
      const categories = await storage.getCategories(userId);
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const category = await storage.getCategoryById(categoryId);
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.post("/api/categories", getOptionalUser, async (req: any, res) => {
    try {
      const { 
        name, 
        icon, 
        color, 
        customImage,
        gradient,
        imageType
      } = req.body;
      
      if (!name || name.trim().length < 2) {
        return res.status(400).json({ message: "Category name must be at least 2 characters" });
      }
      
      // Associate with user if authenticated
      const userId = req.isAuthenticated() ? req.user.id : null;
      
      const newCategory = await storage.createCategory({
        name,
        icon: icon || "note_alt",
        color: color || "primary",
        customImage,
        gradient,
        imageType: imageType || "icon",
        userId
      });
      
      res.status(201).json(newCategory);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.patch("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      const { 
        name, 
        icon, 
        color, 
        customImage,
        gradient,
        imageType
      } = req.body;
      
      if (name && name.trim().length < 2) {
        return res.status(400).json({ message: "Category name must be at least 2 characters" });
      }
      
      const updatedCategory = await storage.updateCategory(categoryId, {
        name,
        icon,
        color,
        customImage,
        gradient,
        imageType
      });
      
      if (!updatedCategory) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(updatedCategory);
    } catch (error) {
      console.error("Error updating category:", error);
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      await storage.deleteCategory(categoryId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting category:", error);
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Notes endpoints
  app.get("/api/categories/:id/notes", async (req, res) => {
    try {
      const categoryId = parseInt(req.params.id);
      
      // First, check if the category exists
      const category = await storage.getCategoryById(categoryId);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const notes = await storage.getNotesByCategoryId(categoryId);
      res.json(notes);
    } catch (error) {
      console.error("Error fetching notes:", error);
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  app.get("/api/notes/:id", async (req, res) => {
    try {
      const noteId = parseInt(req.params.id);
      const note = await storage.getNoteById(noteId);
      
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json(note);
    } catch (error) {
      console.error("Error fetching note:", error);
      res.status(500).json({ message: "Failed to fetch note" });
    }
  });

  app.post("/api/notes", getOptionalUser, async (req: any, res) => {
    try {
      const { title, content, categoryId } = req.body;
      
      if (!title || !title.trim()) {
        return res.status(400).json({ message: "Title is required" });
      }
      
      if (!content || !content.trim()) {
        return res.status(400).json({ message: "Content is required" });
      }
      
      if (!categoryId) {
        return res.status(400).json({ message: "Category ID is required" });
      }
      
      // Associate with user if authenticated
      const userId = req.isAuthenticated() ? req.user.id : null;
      
      const newNote = await storage.createNote({
        title,
        content,
        categoryId,
        userId
      });
      
      res.status(201).json(newNote);
    } catch (error) {
      console.error("Error creating note:", error);
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  app.patch("/api/notes/:id", async (req, res) => {
    try {
      const noteId = parseInt(req.params.id);
      const { title, content } = req.body;
      
      if (title === "") {
        return res.status(400).json({ message: "Title cannot be empty" });
      }
      
      if (content === "") {
        return res.status(400).json({ message: "Content cannot be empty" });
      }
      
      const updatedNote = await storage.updateNote(noteId, {
        title,
        content,
      });
      
      if (!updatedNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json(updatedNote);
    } catch (error) {
      console.error("Error updating note:", error);
      res.status(500).json({ message: "Failed to update note" });
    }
  });

  app.patch("/api/notes/:id/pin", async (req, res) => {
    try {
      const noteId = parseInt(req.params.id);
      const { isPinned } = req.body;
      
      if (typeof isPinned !== 'boolean') {
        return res.status(400).json({ message: "isPinned field must be a boolean" });
      }
      
      const updatedNote = await storage.updateNote(noteId, {
        isPinned,
      });
      
      if (!updatedNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json(updatedNote);
    } catch (error) {
      console.error("Error updating note pin status:", error);
      res.status(500).json({ message: "Failed to update note pin status" });
    }
  });

  app.patch("/api/notes/:id/favorite", async (req, res) => {
    try {
      const noteId = parseInt(req.params.id);
      const { isFavorite } = req.body;
      
      if (typeof isFavorite !== 'boolean') {
        return res.status(400).json({ message: "isFavorite field must be a boolean" });
      }
      
      const updatedNote = await storage.updateNote(noteId, {
        isFavorite,
      });
      
      if (!updatedNote) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json(updatedNote);
    } catch (error) {
      console.error("Error updating note favorite status:", error);
      res.status(500).json({ message: "Failed to update note favorite status" });
    }
  });

  app.delete("/api/notes/:id", async (req, res) => {
    try {
      const noteId = parseInt(req.params.id);
      await storage.deleteNote(noteId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting note:", error);
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  // Image upload endpoint
  app.post("/api/upload", upload.single("image"), (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      // Return the path to the uploaded file
      const filePath = `/uploads/${req.file.filename}`;
      res.json({ 
        url: filePath,
        success: true,
        message: "Image uploaded successfully"
      });
    } catch (error) {
      console.error("Error uploading image:", error);
      res.status(500).json({ 
        message: "Failed to upload image",
        success: false
      });
    }
  });

  // Serve uploaded files
  app.use("/uploads", express.static(uploadDir, { setHeaders: (res) => {
    res.setHeader('Cache-Control', 'public, max-age=31536000');
    res.setHeader('Access-Control-Allow-Origin', '*');
  }}) as express.RequestHandler);

  const httpServer = createServer(app);
  return httpServer;
}
