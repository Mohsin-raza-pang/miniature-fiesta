import { db } from "@db";
import { pool } from "@db";
import { categories, notes, users } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import session from "express-session";

interface CategoryCreateParams {
  name: string;
  icon?: string;
  color?: string;
  customImage?: string;
  gradient?: string;
  imageType?: string;
  userId?: number;
}

interface CategoryUpdateParams {
  name?: string;
  icon?: string;
  color?: string;
  customImage?: string;
  gradient?: string;
  imageType?: string;
}

interface NoteCreateParams {
  title: string;
  content: string;
  categoryId: number;
  userId?: number;
  isPinned?: boolean;
  isFavorite?: boolean;
}

interface NoteUpdateParams {
  title?: string;
  content?: string;
  isPinned?: boolean;
  isFavorite?: boolean;
}

// Create PostgreSQL session store
const PostgresSessionStore = connectPg(session);
const sessionStore = new PostgresSessionStore({
  pool,
  createTableIfMissing: true,
});

export const storage = {
  sessionStore,
  
  // User methods
  getUser: async (id: number) => {
    return db.query.users.findFirst({
      where: eq(users.id, id),
    });
  },
  
  getUserByUsername: async (username: string) => {
    return db.query.users.findFirst({
      where: eq(users.username, username),
    });
  },
  
  createUser: async (data: { 
    username: string; 
    password: string; 
    displayName?: string | null; 
    email?: string | null;
    profileImage?: string | null;
  }) => {
    const [newUser] = await db.insert(users)
      .values({
        username: data.username,
        password: data.password,
        displayName: data.displayName || null,
        email: data.email || null,
        profileImage: data.profileImage || null,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
      
    return newUser;
  },
  // Categories
  getCategories: async (userId: number | null = null) => {
    // Get categories with a count of notes for each
    // If userId is provided, get only user's categories, otherwise get all public categories
    let categoriesWithNotes;
    
    if (userId) {
      // Get categories belonging to this user
      categoriesWithNotes = await db.query.categories.findMany({
        where: eq(categories.userId, userId),
        with: {
          notes: true,
        },
        orderBy: desc(categories.updatedAt),
      });
    } else {
      // Get all public categories (where userId is null)
      // We'll filter them manually since Drizzle ORM has issues with null comparisons
      const allCategories = await db.query.categories.findMany({
        with: {
          notes: true,
        },
        orderBy: desc(categories.updatedAt),
      });
      
      // Filter out categories that have a userId
      categoriesWithNotes = allCategories.filter(cat => cat.userId === null);
    }

    return categoriesWithNotes.map(category => ({
      ...category,
      notesCount: category.notes?.length || 0,
      notes: undefined, // Remove the notes array from the result
    }));
  },

  getCategoryById: async (id: number) => {
    const categoryWithNotes = await db.query.categories.findFirst({
      where: eq(categories.id, id),
      with: {
        notes: true,
      },
    });

    if (!categoryWithNotes) {
      return null;
    }

    return {
      ...categoryWithNotes,
      notesCount: categoryWithNotes.notes?.length || 0,
      notes: undefined, // Remove the notes array from the result
    };
  },

  createCategory: async (params: CategoryCreateParams) => {
    const [newCategory] = await db.insert(categories)
      .values({
        name: params.name,
        icon: params.icon || 'note_alt',
        color: params.color || 'primary',
        customImage: params.customImage,
        gradient: params.gradient,
        imageType: params.imageType || 'icon',
        userId: params.userId,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();

    return newCategory;
  },

  updateCategory: async (id: number, params: CategoryUpdateParams) => {
    const updates: Record<string, any> = {
      updatedAt: new Date(),
    };

    if (params.name !== undefined) updates.name = params.name;
    if (params.icon !== undefined) updates.icon = params.icon;
    if (params.color !== undefined) updates.color = params.color;
    if (params.customImage !== undefined) updates.customImage = params.customImage;
    if (params.gradient !== undefined) updates.gradient = params.gradient;
    if (params.imageType !== undefined) updates.imageType = params.imageType;

    const [updatedCategory] = await db.update(categories)
      .set(updates)
      .where(eq(categories.id, id))
      .returning();

    return updatedCategory || null;
  },

  deleteCategory: async (id: number) => {
    // First delete all notes in this category
    await db.delete(notes).where(eq(notes.categoryId, id));
    
    // Then delete the category
    await db.delete(categories).where(eq(categories.id, id));
    
    return true;
  },

  // Notes
  getNotesByCategoryId: async (categoryId: number) => {
    return db.query.notes.findMany({
      where: eq(notes.categoryId, categoryId),
      orderBy: [
        // First sort by pinned status (pinned notes first)
        desc(notes.isPinned),
        // Then by most recently updated
        desc(notes.updatedAt)
      ],
    });
  },

  getNoteById: async (id: number) => {
    return db.query.notes.findFirst({
      where: eq(notes.id, id),
    });
  },

  createNote: async (params: NoteCreateParams) => {
    const [newNote] = await db.insert(notes)
      .values({
        title: params.title,
        content: params.content,
        categoryId: params.categoryId,
        userId: params.userId,
        isPinned: params.isPinned || false,
        isFavorite: params.isFavorite || false,
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
      
    // Update the parent category's updatedAt timestamp
    await db.update(categories)
      .set({ updatedAt: new Date() })
      .where(eq(categories.id, params.categoryId));

    return newNote;
  },

  updateNote: async (id: number, params: NoteUpdateParams) => {
    const updates: Record<string, any> = {
      updatedAt: new Date(),
    };

    if (params.title !== undefined) updates.title = params.title;
    if (params.content !== undefined) updates.content = params.content;
    if (params.isPinned !== undefined) updates.isPinned = params.isPinned;
    if (params.isFavorite !== undefined) updates.isFavorite = params.isFavorite;

    const [updatedNote] = await db.update(notes)
      .set(updates)
      .where(eq(notes.id, id))
      .returning();

    if (updatedNote) {
      // Also update the parent category's updatedAt timestamp
      await db.update(categories)
        .set({ updatedAt: new Date() })
        .where(eq(categories.id, updatedNote.categoryId));
    }

    return updatedNote || null;
  },

  deleteNote: async (id: number) => {
    // First get the note to find its category
    const note = await db.query.notes.findFirst({
      where: eq(notes.id, id),
    });
    
    if (note) {
      // Delete the note
      await db.delete(notes).where(eq(notes.id, id));
      
      // Update the parent category's updatedAt timestamp
      await db.update(categories)
        .set({ updatedAt: new Date() })
        .where(eq(categories.id, note.categoryId));
    }
    
    return true;
  },
};
