import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  email: text("email").unique(),
  profileImage: text("profile_image"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  displayName: true,
  profileImage: true,
});

export const updateUserSchema = createInsertSchema(users).pick({
  displayName: true,
  email: true,
  profileImage: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull().default("note_alt"),
  color: text("color").notNull().default("primary"),
  customImage: text("custom_image"),
  gradient: text("gradient"),
  imageType: text("image_type").default("icon"),  // "icon", "custom", "gradient"
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const categoriesInsertSchema = createInsertSchema(categories, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters")
});

export type CategoryInsert = z.infer<typeof categoriesInsertSchema>;
export type Category = typeof categories.$inferSelect;

// Notes table
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false).notNull(),
  isFavorite: boolean("is_favorite").default(false).notNull(),
  categoryId: integer("category_id").references(() => categories.id).notNull(),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const notesInsertSchema = createInsertSchema(notes, {
  title: (schema) => schema.min(1, "Title is required"),
  content: (schema) => schema.min(1, "Content is required")
});

export type NoteInsert = z.infer<typeof notesInsertSchema>;
export type Note = typeof notes.$inferSelect;

// Define relations
export const categoriesRelations = relations(categories, ({ many, one }) => ({
  notes: many(notes),
  user: one(users, { fields: [categories.userId], references: [users.id] }),
}));

export const notesRelations = relations(notes, ({ one }) => ({
  category: one(categories, { fields: [notes.categoryId], references: [categories.id] }),
  user: one(users, { fields: [notes.userId], references: [users.id] }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  categories: many(categories),
  notes: many(notes),
}));
